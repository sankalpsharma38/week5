/*
WEEK 3 BASELINE EXAMPLE

Problem:
Async login/register operations can be triggered repeatedly by fast clicks.

Unsafe pattern:
// async submit() {
//   await auth.login(email, password)
// }

Fixed version:
Login.vue and Register.vue use isSubmitting to prevent duplicate operations
and disable the submit button while the async action is running.
