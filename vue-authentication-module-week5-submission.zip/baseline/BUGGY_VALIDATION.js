/*
WEEK 3 BASELINE EXAMPLE
This file documents a deliberately problematic validation approach created
for the exercise because no separate Week 3 buggy starter project was supplied.

Problems:
1. Login/Register would duplicate validation logic.
2. Blur could validate the entire form, causing unrelated errors to appear.
3. Confirmation-password validation did not distinguish empty confirmation.
*/

// Example of the old pattern:
// function validateForm() {
//   errors.email = validateEmail(form.email)
//   errors.password = validatePassword(form.password)
//   errors.confirmPassword = form.password === form.confirmPassword
//     ? ''
//     : 'Passwords do not match.'
// }
//
// input @blur=\"validateForm\"  <-- validates fields the user has not touched.

export const baselineIssues = [
  'Duplicated validation logic',
  'Whole-form validation on individual-field blur',
  'Ambiguous empty confirmation-password message'
]