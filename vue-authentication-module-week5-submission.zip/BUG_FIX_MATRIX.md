# Week 3 Bug / Issue → Fix Matrix

> No separate buggy Week 3 starter ZIP was supplied. The Week 3 baseline was therefore derived from the working Week 2 authentication module and the task requirements. The `baseline/` directory contains deliberately documented problematic patterns used as the comparison baseline. The final `src/` directory contains the corrected implementation.

| ID | Baseline issue | Fixed implementation | Benefit |
|---|---|---|---|
| BUG-01 | Validation logic duplicated across views | `src/utils/validators.js` | Single source of truth |
| BUG-02 | Field blur could trigger unrelated validation | `validateField()` validates only the touched field | Better UX and less unnecessary work |
| BUG-03 | Empty password confirmation could be reported only as mismatch | Explicit required check before equality check | Clearer error messages |
| BUG-04 | Repeated label/input/error markup | Reusable `AuthField.vue` | Better maintainability |
| BUG-05 | Raw passwords could be persisted | SHA-256 demo digest stored as `passwordHash` | Avoids direct raw-password persistence |
| BUG-06 | Direct `localStorage` access could throw | Safe storage wrapper | Prevents uncaught storage errors |
| BUG-07 | Corrupt persisted JSON could break state restoration | Normalization + safe JSON parsing | More resilient startup |
| BUG-08 | Redirect query could be used without validation | `getSafeRedirect()` | Prevents unsafe external redirect values |
| BUG-09 | Async auth action could be submitted repeatedly | `isSubmitting` guard | Prevents duplicate operations |
| BUG-10 | Authentication views loaded eagerly | Lazy-loaded route components | Smaller initial route load |

## Annotation convention

The corrected source contains comments where the change is most useful to understand. The `baseline/` files preserve the problematic patterns as documentation without shipping them as the production implementation.
