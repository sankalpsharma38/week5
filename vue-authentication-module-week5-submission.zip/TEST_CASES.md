# Week 5 Test Case Summary

| ID | Module | Scenario | Type | Expected Result |
|---|---|---|---|---|
| TC01 | AuthField | Render email field | Normal | Label/input render |
| TC02 | AuthField | Change value | Normal | update:modelValue emitted |
| TC03 | AuthField | Show error | Edge | Error + ARIA state shown |
| TC04 | AuthField | Blur | Normal | Blur event emitted |
| TC05 | AuthCard | Title and slot | Normal | Content renders |
| TC06 | Validators | Empty name | Edge | Required error |
| TC07 | Validators | Invalid email | Edge | Email error |
| TC08 | Validators | Short password | Edge | Length error |
| TC09 | Validators | Password mismatch | Edge | Mismatch error |
| TC10 | Redirect | External URL | Security edge | Safe fallback |
| TC11 | Storage | JSON round trip | Normal | Data recovered |
| TC12 | Storage | Corrupt JSON | Edge | Fallback used |
| TC13 | Auth | Register | Normal | User created |
| TC14 | Auth | Duplicate registration | Edge | Request rejected |
| TC15 | Auth | Wrong password | Edge | Login rejected |
| TC16 | Auth | Correct login | Normal | Session created |
| TC17 | Auth | Restore session | Normal | User restored |
| TC18 | Auth | Corrupt session | Edge | Invalid state ignored |
| TC19 | Auth | Logout | Normal | Session cleared |
| TC20 | Header | Toggle mobile menu | Normal | Menu state changes |
| TC21 | Header | Logout | Normal | Login navigation requested |
