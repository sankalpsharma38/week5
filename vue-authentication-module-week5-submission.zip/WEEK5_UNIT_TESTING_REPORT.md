# WEEK 5 INTERNSHIP REPORT

## Unit Testing & Quality Assurance – VueJS Authentication Application

### 1. Introduction
Week 5 focused on introducing a systematic unit-testing and quality-assurance process to the VueJS authentication application developed in the previous internship weeks. The project already contained Login, Registration and Dashboard views, reusable UI components, Pinia state management, Vue Router navigation protection, client-side validation and browser-storage utilities. The purpose of this week was to verify these individual units independently and to reduce the risk of regressions when the application is modified in future.

### 2. Objective
The main objectives were to configure a modern testing environment, write focused unit tests using Vitest and Vue Test Utils, cover normal and edge cases, verify authentication and validation behavior, test reusable components, and document a repeatable QA workflow.

### 3. Testing Technology
- VueJS 3
- Vitest
- Vue Test Utils
- jsdom
- Pinia
- Vue Router
- Vite

### 4. Components and Functions Tested
The test suite covers AuthField, AuthCard, StatCard, FeatureCard and AppHeader. Utility tests cover validators, safe redirects and browser-storage helpers. Pinia authentication tests cover registration, duplicate accounts, login, incorrect credentials, session restoration, malformed persisted data and logout.

### 5. Test Cases
| Area | Test | Expected Result |
|---|---|---|
| AuthField | Render label/input | Correct field is displayed |
| AuthField | Update input | update:modelValue event is emitted |
| AuthField | Validation error | Error and ARIA attributes appear |
| AuthField | Blur | Blur event is emitted |
| AuthCard | Render title/subtitle | Content appears correctly |
| Validators | Empty name | Required error returned |
| Validators | Invalid email | Email error returned |
| Validators | Short password | Minimum-length error returned |
| Validators | Password mismatch | Mismatch error returned |
| Redirect | External URL | Redirect falls back to dashboard |
| Storage | Write/read/remove | JSON persistence works |
| Storage | Malformed JSON | Fallback is returned |
| Auth Store | Valid registration | User is created |
| Auth Store | Duplicate email | Registration is rejected |
| Auth Store | Wrong password | Login is rejected |
| Auth Store | Correct login | Session is created |
| Auth Store | Session restore | Existing session is restored |
| Auth Store | Corrupt state | Invalid data is ignored |
| Auth Store | Logout | Session is cleared |
| Header | Mobile menu | Menu opens/closes |
| Header | Logout | Session clears and login navigation occurs |

### 6. Edge Cases Covered
The suite deliberately tests empty values, malformed email addresses, short passwords, mismatched confirmation passwords, duplicate email addresses, incorrect credentials, malformed localStorage JSON, unsafe external redirects and session clearing. These cases are important because they represent common failure conditions rather than only the successful user path.

### 7. Quality Assurance Approach
Testing follows a repeatable Arrange–Act–Assert pattern. Components are mounted in isolation and their rendered output, emitted events and interaction behavior are inspected. Pinia tests use a fresh testing store for each case so state does not leak between tests. Browser storage is cleared after each test. The jsdom environment provides the browser APIs required by the application during automated testing.

### 8. Issues and Verification
The test suite is designed to catch regressions in validation, component communication, authentication state and persistence. In particular, tests verify that passwords are not exposed on the authenticated user object, duplicate accounts are rejected, malformed persisted data does not become active state, and unsafe redirect values are rejected.

### 9. How to Run Tests
```text
npm install
npm test
```

For watch mode:
```text
npm run test:watch
```

For coverage:
```text
npm run test:coverage
```

### 10. Insights Gained
Unit testing demonstrates that individual components can be verified without manually checking the entire application after every code change. It also encourages smaller components, clear interfaces, predictable state transitions and separation of responsibilities. Edge-case testing is especially valuable for authentication because incorrect input and corrupted client-side state should be handled safely.

### 11. Limitations
The application remains an educational frontend authentication demonstration. Unit tests do not replace integration or end-to-end testing, and jsdom does not reproduce every browser behavior. Production applications should add API integration tests, end-to-end tests, security testing and CI-based automated test execution.

### 12. Conclusion
Week 5 establishes a foundation for automated quality assurance in the VueJS application. The project now contains component, utility and authentication-store tests covering normal behavior and important edge cases. The documented commands make the test suite reproducible for future development and provide a practical foundation for TDD and regression prevention.
