# Submission Checklist

- [x] VueJS source code
- [x] Debugging/refactoring documentation
- [x] Bug/issue-to-fix matrix
- [x] Performance methodology
- [x] Before/after evidence table ready for DevTools values
- [x] Functional test matrix
- [x] README
- [x] Baseline examples documenting the Week 3 exercise
- [ ] Run `npm install`
- [ ] Run `npm run dev`
- [ ] Run functional tests
- [ ] Run `npm run build`
- [ ] Record browser DevTools before/after metrics
- [ ] Add screenshots of DevTools results if required by evaluator
