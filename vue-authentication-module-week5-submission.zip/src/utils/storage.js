const PREFIX = 'vue-auth-week3'

function key(name) {
  return `${PREFIX}:${name}`
}

export function readJson(name, fallback = null) {
  try {
    const raw = localStorage.getItem(key(name))
    if (!raw) return fallback
    return JSON.parse(raw)
  } catch {
    return fallback
  }
}

export function writeJson(name, value) {
  try {
    localStorage.setItem(key(name), JSON.stringify(value))
    return true
  } catch {
    return false
  }
}

export function remove(name) {
  try {
    localStorage.removeItem(key(name))
    return true
  } catch {
    return false
  }
}