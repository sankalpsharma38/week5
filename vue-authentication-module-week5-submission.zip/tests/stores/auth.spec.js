import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../../src/stores/auth'

describe('auth store', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it('registers a user and prevents duplicate email registration', async () => {
    const auth = useAuthStore()
    const first = await auth.register({ name: 'Alex User', email: 'Alex@Example.com', password: 'password123' })
    const duplicate = await auth.register({ name: 'Another', email: ' alex@example.com ', password: 'password456' })
    expect(first.ok).toBe(true)
    expect(duplicate.ok).toBe(false)
    expect(duplicate.message).toContain('already exists')
    expect(auth.users).toHaveLength(1)
    expect(auth.users[0].email).toBe('alex@example.com')
    expect(auth.users[0].passwordHash).not.toBe('password123')
  })

  it('logs in with correct credentials and rejects wrong credentials', async () => {
    const auth = useAuthStore()
    await auth.register({ name: 'Alex User', email: 'alex@example.com', password: 'password123' })
    const wrong = await auth.login('alex@example.com', 'wrongpass')
    expect(wrong.ok).toBe(false)
    expect(auth.isAuthenticated).toBe(false)

    const correct = await auth.login(' ALEX@EXAMPLE.COM ', 'password123')
    expect(correct.ok).toBe(true)
    expect(auth.isAuthenticated).toBe(true)
    expect(auth.currentUser.email).toBe('alex@example.com')
    expect(auth.currentUser.passwordHash).toBeUndefined()
  })

  it('restores a valid session from storage', async () => {
    const first = useAuthStore()
    await first.register({ name: 'Alex User', email: 'alex@example.com', password: 'password123' })
    await first.login('alex@example.com', 'password123')

    setActivePinia(createPinia())
    const second = useAuthStore()
    expect(second.isAuthenticated).toBe(true)
    expect(second.currentUser.email).toBe('alex@example.com')
  })

  it('ignores malformed persisted users and sessions', () => {
    localStorage.setItem('vue-auth-week3:users', JSON.stringify([{ bad: true }]))
    localStorage.setItem('vue-auth-week3:session', JSON.stringify({ bad: true }))
    const auth = useAuthStore()
    expect(auth.users).toEqual([])
    expect(auth.currentUser).toBeNull()
  })

  it('logs out and clears the session', async () => {
    const auth = useAuthStore()
    await auth.register({ name: 'Alex User', email: 'alex@example.com', password: 'password123' })
    await auth.login('alex@example.com', 'password123')
    await auth.logout()
    expect(auth.isAuthenticated).toBe(false)
    expect(localStorage.getItem('vue-auth-week3:session')).toBeNull()
  })
})
