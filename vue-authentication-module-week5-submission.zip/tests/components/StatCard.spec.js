import { mount } from '@vue/test-utils'
import StatCard from '../../src/components/StatCard.vue'

describe('StatCard', () => {
  it('renders all statistic information', () => {
    const wrapper = mount(StatCard, { props: { icon: '✓', label: 'Navigation', value: 'Protected', hint: 'Router guard enabled' } })
    expect(wrapper.text()).toContain('Navigation')
    expect(wrapper.text()).toContain('Protected')
    expect(wrapper.text()).toContain('Router guard enabled')
  })
})
