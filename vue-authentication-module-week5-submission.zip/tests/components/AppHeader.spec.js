import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { vi } from 'vitest'
import AppHeader from '../../src/components/AppHeader.vue'
import { useAuthStore } from '../../src/stores/auth'

const replace = vi.fn()
const useRouterMock = () => ({ replace })
vi.mock('vue-router', async () => {
  const actual = await vi.importActual('vue-router')
  return { ...actual, useRouter: useRouterMock }
})

describe('AppHeader', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    replace.mockReset()
  })

  it('toggles the mobile navigation menu', async () => {
    const wrapper = mount(AppHeader)
    const button = wrapper.find('.menu-toggle')
    expect(button.attributes('aria-expanded')).toBe('false')
    await button.trigger('click')
    expect(button.attributes('aria-expanded')).toBe('true')
    expect(wrapper.find('.main-nav').classes()).toContain('is-open')
  })

  it('logs out and navigates to login', async () => {
    const auth = useAuthStore()
    const wrapper = mount(AppHeader)
    auth.currentUser = { name: 'Alex', email: 'alex@example.com' }
    await wrapper.find('.nav-logout').trigger('click')
    expect(auth.isAuthenticated).toBe(false)
    expect(replace).toHaveBeenCalledWith({ name: 'login' })
  })
})
