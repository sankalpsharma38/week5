import { mount } from '@vue/test-utils'
import FeatureCard from '../../src/components/FeatureCard.vue'

describe('FeatureCard', () => {
  it('renders number, title and description', () => {
    const wrapper = mount(FeatureCard, { props: { number: '01', title: 'Responsive grid', description: 'Adapts across devices.' } })
    expect(wrapper.find('.feature-number').text()).toBe('01')
    expect(wrapper.find('h3').text()).toBe('Responsive grid')
    expect(wrapper.find('p').text()).toBe('Adapts across devices.')
  })
})
