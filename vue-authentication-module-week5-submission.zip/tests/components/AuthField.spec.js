import { mount } from '@vue/test-utils'
import AuthField from '../../src/components/AuthField.vue'

describe('AuthField', () => {
  it('renders label, input and placeholder', () => {
    const wrapper = mount(AuthField, { props: { id: 'email', label: 'Email', placeholder: 'Enter email' } })
    expect(wrapper.find('label').text()).toBe('Email')
    expect(wrapper.find('input').attributes('placeholder')).toBe('Enter email')
    expect(wrapper.find('input').attributes('name')).toBe('email')
  })

  it('emits the updated value', async () => {
    const wrapper = mount(AuthField, { props: { id: 'email', label: 'Email', modelValue: '' } })
    await wrapper.find('input').setValue('user@example.com')
    expect(wrapper.emitted('update:modelValue')[0]).toEqual(['user@example.com'])
  })

  it('shows validation error and accessibility attributes', () => {
    const wrapper = mount(AuthField, { props: { id: 'email', label: 'Email', error: 'Email is required.' } })
    expect(wrapper.find('.error').text()).toBe('Email is required.')
    expect(wrapper.find('input').attributes('aria-invalid')).toBe('true')
    expect(wrapper.find('input').attributes('aria-describedby')).toBe('email-error')
  })

  it('emits blur events', async () => {
    const wrapper = mount(AuthField, { props: { id: 'email', label: 'Email' } })
    await wrapper.find('input').trigger('blur')
    expect(wrapper.emitted('blur')).toHaveLength(1)
  })
})
