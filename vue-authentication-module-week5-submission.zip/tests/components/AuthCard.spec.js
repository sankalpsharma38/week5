import { mount } from '@vue/test-utils'
import AuthCard from '../../src/components/AuthCard.vue'

describe('AuthCard', () => {
  it('renders title, subtitle and slot content', () => {
    const wrapper = mount(AuthCard, {
      props: { title: 'Sign in', subtitle: 'Welcome back' },
      slots: { default: '<button>Login</button>' }
    })
    expect(wrapper.find('h1').text()).toBe('Sign in')
    expect(wrapper.find('.muted').text()).toBe('Welcome back')
    expect(wrapper.find('button').text()).toBe('Login')
  })

  it('does not render subtitle when omitted', () => {
    const wrapper = mount(AuthCard, { props: { title: 'Register' } })
    expect(wrapper.find('.muted').exists()).toBe(false)
  })
})
