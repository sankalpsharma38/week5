import { getSafeRedirect } from '../../src/utils/redirect'

describe('getSafeRedirect', () => {
  it('allows internal paths', () => {
    expect(getSafeRedirect('/dashboard')).toBe('/dashboard')
    expect(getSafeRedirect('/dashboard?tab=home')).toBe('/dashboard?tab=home')
  })

  it('rejects external and malformed redirects', () => {
    expect(getSafeRedirect('//example.com')).toBe('/dashboard')
    expect(getSafeRedirect('https://example.com')).toBe('/dashboard')
    expect(getSafeRedirect(null)).toBe('/dashboard')
  })
})
