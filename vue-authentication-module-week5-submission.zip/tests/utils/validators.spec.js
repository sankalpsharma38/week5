import { validateName, validateEmail, validatePassword, validatePasswordConfirmation } from '../../src/utils/validators'

describe('validation utilities', () => {
  it('validates names', () => {
    expect(validateName('')).toBe('Name is required.')
    expect(validateName('A')).toContain('at least 2')
    expect(validateName('Alex')).toBe('')
  })

  it('validates email addresses', () => {
    expect(validateEmail('')).toBe('Email is required.')
    expect(validateEmail('bad-email')).toBe('Enter a valid email address.')
    expect(validateEmail('alex@example.com')).toBe('')
  })

  it('validates password length', () => {
    expect(validatePassword('')).toBe('Password is required.')
    expect(validatePassword('1234567')).toContain('at least 8')
    expect(validatePassword('12345678')).toBe('')
  })

  it('validates password confirmation', () => {
    expect(validatePasswordConfirmation('password', '')).toBe('Please confirm your password.')
    expect(validatePasswordConfirmation('password', 'different')).toBe('Passwords do not match.')
    expect(validatePasswordConfirmation('password', 'password')).toBe('')
  })
})
