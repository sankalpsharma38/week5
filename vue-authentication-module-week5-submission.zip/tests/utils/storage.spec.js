import { readJson, writeJson, remove } from '../../src/utils/storage'

describe('storage utilities', () => {
  it('writes, reads and removes JSON data', () => {
    expect(writeJson('test', { value: 42 })).toBe(true)
    expect(readJson('test')).toEqual({ value: 42 })
    expect(remove('test')).toBe(true)
    expect(readJson('test', 'fallback')).toBe('fallback')
  })

  it('returns fallback for malformed JSON', () => {
    localStorage.setItem('vue-auth-week3:broken', '{invalid')
    expect(readJson('broken', [])).toEqual([])
  })
})
