# Week 4 UI/UX Test Checklist

## Functional
- [ ] Register
- [ ] Login
- [ ] Protected Dashboard
- [ ] Refresh/session restore
- [ ] Logout
- [ ] Validation/error states

## Responsive widths
- [ ] 320px
- [ ] 375px
- [ ] 430px
- [ ] 768px
- [ ] 1024px
- [ ] 1440px

## UI/UX
- [ ] No horizontal overflow
- [ ] Mobile menu opens/closes
- [ ] Forms remain readable
- [ ] Buttons remain comfortable to tap
- [ ] Dashboard cards stack correctly
- [ ] Footer remains readable

## Accessibility
- [ ] Keyboard tab navigation
- [ ] Visible focus state
- [ ] Form labels
- [ ] Error messages
- [ ] Mobile menu expanded state

## Evidence screenshots
1. Desktop Login
2. Mobile Login
3. Desktop Dashboard
4. Mobile Dashboard
5. Responsive DevTools viewport
